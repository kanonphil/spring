package com.green.rest_study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestStudyApplication.class, args);
	}

}
